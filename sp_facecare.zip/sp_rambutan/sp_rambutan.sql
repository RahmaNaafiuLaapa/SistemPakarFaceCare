-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Jan 2023 pada 10.46
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sp_rambutan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `aturan`
--

CREATE TABLE `aturan` (
  `id_aturan` int(11) NOT NULL,
  `id_penyakit` int(11) NOT NULL,
  `id_gejala` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `aturan`
--

INSERT INTO `aturan` (`id_aturan`, `id_penyakit`, `id_gejala`) VALUES
(1, 1, 1),
(2, 1, 13),
(3, 1, 2),
(4, 1, 3),
(5, 1, 4),
(14, 2, 1),
(15, 2, 13),
(16, 2, 5),
(17, 2, 6),
(18, 2, 7),
(19, 3, 1),
(20, 3, 13),
(21, 3, 3),
(22, 3, 4),
(23, 3, 5),
(24, 3, 7),
(25, 3, 8),
(26, 4, 1),
(27, 4, 2),
(28, 4, 4),
(29, 4, 6),
(30, 4, 9),
(31, 5, 1),
(32, 5, 13),
(33, 5, 2),
(34, 5, 6),
(35, 5, 8),
(36, 6, 11),
(37, 6, 12),
(38, 6, 13),
(39, 6, 2),
(40, 6, 5),
(41, 6, 6),
(42, 7, 1),
(43, 7, 13),
(44, 7, 2),
(45, 7, 5),
(46, 7, 6),
(47, 8, 1),
(48, 8, 10),
(49, 8, 13),
(50, 8, 5),
(51, 8, 6);

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala`
--

CREATE TABLE `gejala` (
  `id_gejala` int(11) NOT NULL,
  `kode_gejala` varchar(5) NOT NULL,
  `nama_gejala` text NOT NULL,
  `nilai_cf` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gejala`
--

INSERT INTO `gejala` (`id_gejala`, `kode_gejala`, `nama_gejala`, `nilai_cf`) VALUES
(1, 'KG1', 'Memiliki bekas jerawat', 0.1),
(2, 'KG2', 'Mempunyai Warna Kulit Tidak Merata', 0.8),
(3, 'KG3', 'memiliki komedo', 0.6),
(4, 'KG4', 'mempunyai kuli bertekstur', 0.4),
(5, 'KG5', 'memiliki jerawat', 0.8),
(6, 'KG6', 'memiliki kerutan pada wajah', 0.6),
(7, 'KG7', 'mempunyai minyak berlebih pada wajah', 0.8),
(8, 'KG8', 'memiliki kulit kusam', 0.6),
(9, 'KG9', 'mempunyai bopeng/scar', 0.8),
(10, 'KG10', 'mempunyai pigmen', 0.6),
(11, 'KG11', 'mempunyai roscea', 0.6),
(12, 'KG12', 'memiliki spidervein', 0.8),
(13, 'KG13', 'nemiliki pori pori besar', 0.8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_lengkap` varchar(30) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `level` enum('Admin','User') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_lengkap`, `username`, `password`, `level`) VALUES
(1, 'Administrator', 'admin', 'admin', 'Admin'),
(2, 'Rahma Nafiu', 'rahma', '12345', 'User');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penyakit`
--

CREATE TABLE `penyakit` (
  `id_penyakit` int(11) NOT NULL,
  `kode_penyakit` varchar(5) NOT NULL,
  `nama_penyakit` varchar(50) NOT NULL,
  `deskripsi` text NOT NULL,
  `solusi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penyakit`
--

INSERT INTO `penyakit` (`id_penyakit`, `kode_penyakit`, `nama_penyakit`, `deskripsi`, `solusi`) VALUES
(1, 'KP1', 'Diamond Peel', 'presentase yang di dapatkan dari permasalahan kulit wajah dengan jenis kulit         yaitu  ', 'jenis perawatan kulit yang dibutuhkan wajah anda yaitu DIAMOND PEEL\n\nDiamonds peel merupakan perawatan yang menggunakan alat dengan ujung yang dilapisi butiran berlian. Perawatan ini dilakukan agar kulit tereksfoliasi untuk mengangkat sel kulit mati.\n\nFungsi peeling berlian adalah untuk mengangkat komedo, memudarkan flek hitam, meningkatkan elastisitas kulit dan kolagen. Sehingga kulit akan lebih bersih, bersinar dan halus.\n'),
(2, 'KP2', 'Photodinamic Terapy', 'presentase yang di dapatkan dari permasalahan kulit wajah dengan jenis kulit         yaitu  ', 'jenis perawatan kulit yang dibutuhkan wajah anda yaitu PHOTODINAMIC TERAPY\n\ntreatment PDT adalah sebuah treatment kecantikan yang menggunakan metode cahaya. Bagi Anda yang mengalami permasalahan kulit wajah, seperti jerawat serta bekasnya, bopeng, dan masalah penuaan kulit treatment PDT (Photodynamic Therapy)inilah jawabanya.\n\n\n\n\n'),
(3, 'KP3', 'Derma Booster', 'presentase yang di dapatkan dari permasalahan kulit wajah dengan jenis kulit         yaitu', 'jenis perawatan kulit yang dibutuhkan wajah anda yaitu DERMA BOOSTER\n\nperawatan wajah yang bertujuan untuk mengangkat sel kulit mati, mencerahkan, menghaluskan, dan menutrisi kulit. Dalam tindakan prosedurnya, perawatan ini menggunakan serum khusus, serta capsugen atau batu apung. Durasi pengerjaan dari Derma Skin Booster membutuhkan waktu sekitar 30-45 menit.'),
(4, 'KP4', 'Derma Scar', 'presentase yang di dapatkan dari permasalahan kulit wajah dengan jenis kulit         yaitu ', 'jenis perawatan kulit yang dibutuhkan wajah anda yaitu DERMA SCAR\n\nperawatan menggunakan mesin berteknologi tinggi yang mampu meratakan tekstur dan warna kulit wajah sekaligus meremajakannya.'),
(5, 'KP5', 'Laser Pigmen', 'presentase yang di dapatkan dari permasalahan kulit wajah dengan jenis kulit         yaitu ', 'jenis perawatan kulit yang dibutuhkan wajah anda yaitu LASER PIGMEN\n\nLaser modern dengan media Nd-Yag 1064 nm, Q-Switch, Double Frequency. Laser ini sangat efektif untuk menghilangkan noda hitam/flek, tanda lahir (nevus otta).\n'),
(6, 'KP7', 'Laser CO2', 'presentase yang di dapatkan dari permasalahan kulit wajah dengan jenis kulit         yaitu ', 'jenis perawatan kulit yang dibutuhkan wajah anda yaitu LASER CO2\n\n\nJenis laser ini bekerja dengan mengangkat lapisan kulit terluar (epidermis) dan memanaskan lapisan kulit di bawahnya (dermis). Proses tersebut bisa merangsang pertumbuhan serat kolagen baru pada kulit dan dapat membantu pertumbuhan jaringan kulit baru yang lebih lembut.\n'),
(7, 'KP8', 'Laser Toning', 'presentase yang di dapatkan dari permasalahan kulit wajah dengan jenis kulit         yaitu  ', 'Jenis perawatan kulit yang dibutuhkan wajah anda yaitu LASER TONING\n\n\nprosedur perawatan wajah menggunakan teknologi laser untuk memperbaiki masalah kulit di lapisan dermis. Karena perawatan ini tanpa melewati prosedur bedah, maka relatif aman dan minim risiko, tidak menimbulkan rasa nyeri dan tidak butuh waktu pemulihan yang lama.'),
(8, 'KP6', 'Laser Peel', 'presentase yang di dapatkan dari permasalahan kulit wajah dengan jenis kulit         yaitu ', 'jenis perawatan kulit yang dibutuhkan wajah anda yaitu LASER PEEL\n\n\nLaser Peeling adalah prosedur perawatan kulit dengan menggunakan laser CO2 untuk membantu menstimulasi pertumbuhan kolagen, mengatasi problem pigmentasi, jaringan parut (scars) dan memperbaiki kualitas kulit.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat`
--

CREATE TABLE `riwayat` (
  `id_riwayat` int(11) NOT NULL,
  `id_pengguna` int(11) DEFAULT NULL,
  `tanggal` date NOT NULL,
  `id_penyakit` int(11) DEFAULT NULL,
  `metode` enum('Forward Chaining','Certainty Factor') NOT NULL,
  `nilai` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `riwayat`
--

INSERT INTO `riwayat` (`id_riwayat`, `id_pengguna`, `tanggal`, `id_penyakit`, `metode`, `nilai`) VALUES
(1, 2, '2023-01-30', 1, 'Forward Chaining', NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `aturan`
--
ALTER TABLE `aturan`
  ADD PRIMARY KEY (`id_aturan`) USING BTREE,
  ADD KEY `id_penyakit` (`id_penyakit`),
  ADD KEY `id_gejala` (`id_gejala`);

--
-- Indeks untuk tabel `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id_gejala`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`) USING BTREE;

--
-- Indeks untuk tabel `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`id_penyakit`);

--
-- Indeks untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  ADD PRIMARY KEY (`id_riwayat`),
  ADD KEY `id_penyakit` (`id_penyakit`),
  ADD KEY `id_pengguna` (`id_pengguna`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `aturan`
--
ALTER TABLE `aturan`
  MODIFY `id_aturan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT untuk tabel `gejala`
--
ALTER TABLE `gejala`
  MODIFY `id_gejala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `penyakit`
--
ALTER TABLE `penyakit`
  MODIFY `id_penyakit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  MODIFY `id_riwayat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `aturan`
--
ALTER TABLE `aturan`
  ADD CONSTRAINT `aturan_ibfk_1` FOREIGN KEY (`id_penyakit`) REFERENCES `penyakit` (`id_penyakit`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `aturan_ibfk_2` FOREIGN KEY (`id_gejala`) REFERENCES `gejala` (`id_gejala`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  ADD CONSTRAINT `riwayat_ibfk_1` FOREIGN KEY (`id_penyakit`) REFERENCES `penyakit` (`id_penyakit`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `riwayat_ibfk_2` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
